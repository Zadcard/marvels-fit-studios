# Handoff: Marvel's Fit Studios — Full Design System

> **For Claude Code** — everything you need to implement the Marvel's Fit Studios design system in the existing Next.js codebase.

---

## Overview

This package contains the complete design system and UI prototypes for **Marvel's Fit Studios** — a premium performance training studio in Giza, Egypt. The codebase is a Next.js app with Tailwind, Prisma/Neon, and NextAuth already in place.

The designs cover 7 surfaces:
1. Design System (tokens, components)
2. Landing Page
3. Admin Dashboard (7 workspaces)
4. Coach Dashboard (5 workspaces)
5. Client Mobile App (4 screens)
6. Onboarding / Join Flow (5 steps)
7. Icon Set (56 SVG icons)

---

## About the Design Files

The `.html` files in this bundle are **high-fidelity design references** — fully interactive prototypes built in plain HTML/CSS/React (via CDN Babel). They show the intended look, layout, interactions, and copy **exactly** as designed.

Your task is to **recreate these designs in the existing Next.js codebase** (`app/`, `components/`, etc.) using the established patterns — Tailwind v4, the `mv-*` CSS custom properties already defined in `app/globals.css`, and the existing component structure in `components/dashboard/` and `components/landing/`.

**Do not copy the HTML files directly into the app.** Use them as a pixel-perfect reference.

---

## Fidelity

**High-fidelity.** All colors, typography, spacing, border radii, shadows, and interactions are final. Recreate pixel-perfectly using the existing design tokens in `app/globals.css`.

---

## Design Tokens (from `app/globals.css`)

All tokens are already defined. Use them. Do not invent new values.

```css
--mv-bg: #000000
--mv-bg-soft: #0a0a0a
--mv-surface: #111111
--mv-surface-strong: #1a1a1a
--mv-text: #ffffff
--mv-muted: #a0a0a0
--mv-muted-strong: #cccccc
--mv-line: #333333
--mv-line-strong: #444444
--mv-primary: #e62429          /* Marvel Red — all CTAs */
--mv-primary-deep: #b91c21     /* Hover state */
--mv-primary-soft: #2d1011     /* Soft backgrounds */
--mv-success: #25d366
--mv-warning: #f59e0b
--mv-danger: #ef4444
--radius-sm: 14px
--radius-md: 22px
--radius-lg: 30px
--radius-xl: 999px             /* Pills & buttons */
```

**Typography:**
- Display / headings: `Space Grotesk` (500, 700) — `var(--font-display)`
- Body: `Manrope` (400–800) — `var(--font-body)`
- Eyebrow / labels: 0.68–0.74rem, weight 800, letter-spacing 0.18–0.22em, UPPERCASE
- Heading letter-spacing: -0.03em

---

## Screens / Views

### 1. Landing Page (`Landing Page.html`)

**Purpose:** Public marketing page. Converts visitors to membership requests.

**Sections (top to bottom):**
- `<header>` sticky nav — glass blur `rgba(14,14,14,.96)`, rounded bottom `0 0 34px 34px`, logo left, nav links center, Login + Join Now right
- Hero — centered, max-width 860px. H1: `clamp(2.9rem, 9vw, 6rem)`, gradient text (`linear-gradient(180deg, #fff 25%, rgba(255,255,255,.38) 100%)`), badges row, CTA buttons
- About — 2-col grid: text panel left, logo panel right (filter: brightness(0) invert(1))
- Services — 4-card carousel (desktop: grid; mobile: horizontal scroll)
- Reviews — 3-card carousel, same pattern
- FAQ — 2-col accordion with `grid-template-rows: 0fr → 1fr` expand animation
- Footer — CTA band + 4-col grid + social icons with brand color hovers
- Join Modal — fixed overlay, glass panel, slide-in animation, Egyptian phone validation

**Key interactions:**
- Nav hamburger toggle with animated bars (3 spans)
- FAQ accordion: only one open at a time
- Join modal: `openJoin()` / `closeJoin()`, Escape key closes, phone regex: `/^(\+20|0)?1[0-9]{9}$/`
- Carousel: drag-to-scroll on mobile, CSS grid on desktop
- Scroll-reveal: IntersectionObserver on `.reveal` elements → add `.in` class

**Existing components to update:**
- `components/landing/landing-sections.tsx` — LandingHeader, LandingServicesSection, LandingReviewsSection, LandingFooter
- `components/landing/landing-join-modal.tsx` — LandingJoinModal
- `components/landing/join-now-form.tsx` — JoinNowForm (already has server action)
- `app/landing.css` — all landing-specific styles live here

---

### 2. Admin Dashboard (`Admin Dashboard.html`)

**Purpose:** Studio management. 7 navigable workspaces.

**Shell:** `dashboard-shell.css` already exists. Sidebar (fixed, 282px, slides in on mobile, sticky on ≥1024px), Topbar (sticky, backdrop-blur), content area.

**Workspaces to implement / complete:**

| Workspace | Route | Status in codebase |
|---|---|---|
| Overview | `/admin` | Partially done |
| Clients | `/admin/clients` | Done (needs visual polish) |
| Sessions | `/admin/sessions` | Done |
| Coaches | `/admin/coaches` | Done |
| Schedule | `/admin/schedule` | Missing |
| Payments | `/admin/payments` | Missing |
| Settings | `/admin/settings` | Partially done |

**Schedule workspace** — 7-day grid, `repeat(7, 1fr)`, each day column has session cards with status badges + capacity fill bars. See `Icon Set.html` section 08 for visual reference.

**Payments workspace** — Table: Member, Membership, Amount, Status, Due Date, Cycle, Actions. Mini-stat row: Paid / Due soon / Overdue / Collected. Search + status filter. "Mark paid" and "Remind" inline actions.

**Key components (already exist, use them):**
- `DashboardStatCard` — KPI tiles
- `DashboardMiniStat` — small priority tiles
- `DashboardSurfaceNote` — eyebrow + h2 + bullet list callout
- `DashboardStatusBadge` — tone-aware badge
- `DashboardModal` — dialog overlay
- `DashboardManagementToolbar` — search + filters + summary

---

### 3. Coach Dashboard (`Coach Dashboard.html`)

**Purpose:** Coach-facing workspace. Separate role, same shell.

**Routes:** `/coach`, `/coach/sessions`, `/coach/clients`, `/coach/schedule`, `/coach/settings`

**Key differences from Admin:**
- Sidebar accent: same red, but label says "Coach workspace"
- Avatar gradient: `linear-gradient(135deg, #3b82f6, #8b5cf6)` (blue-purple, not red)
- Sessions workspace has an inline **post-session note textarea** — saves via `saveCoachSessionNote` action (already exists in `app/actions/coach-session-notes.ts`)
- Clients workspace: roster with momentum flags (On track / Needs check-in / Flagged), detail panel, note textarea
- No Payments or bulk-import pages

**Existing components:**
- `components/dashboard/coach-overview-workspace.tsx`
- `components/dashboard/coach-sessions-workspace.tsx`
- `components/dashboard/coach-clients-workspace.tsx`
- `components/dashboard/coach-schedule-workspace.tsx`

**Missing: Coach Settings workspace** — profile form (name, email, phone, specialization) + notification toggles. Create `components/dashboard/coach-settings-workspace.tsx`.

---

### 4. Client Mobile App (`Client Mobile.html`)

**Purpose:** Member-facing app experience. Currently missing from the codebase — build as `/client/*` routes.

**Routes to create:**

| Screen | Route | Description |
|---|---|---|
| Home | `/client` | Greeting, today's session hero card, stats, progress, upcoming |
| Book | `/client/book` | Session list with fill bars, select + confirm |
| Booking confirm | `/client/book/confirm` | Success state |
| Progress | `/client/progress` | Membership card, stats grid, program targets, coach notes |
| Profile | `/client/profile` | Member info, coach card, account settings |

**Today's session hero card:**
- `border: 1px solid rgba(230,36,41,.28)`, `border-radius: 22px`
- Radial gradient background: `radial-gradient(circle at 90% 10%, rgba(230,36,41,.22), transparent 50%), linear-gradient(180deg, #1c1c1c, #0f0f0f)`
- 3-col stat row separated by `border-right: 1px solid rgba(255,255,255,.08)`
- Book CTA: full-width pill button, red gradient, glow shadow

**Membership card (progress screen):**
- Sessions remaining: display as `{used} of {total} sessions used`
- Fill bar: `linear-gradient(90deg, var(--mv-primary), #ff6b6f)`, height 8px
- Renew button: `btn-outline` style

**Booking flow:**
- Each session card: selectable, shows fill bar for Group sessions
- Confirm button disabled until selection
- Success screen: green check ring animation (`animation: popIn .5s cubic-bezier(.16,1.5,.3,1)`)

**Mobile-specific:** Tab bar fixed at bottom, height 64px, `backdrop-filter: blur(20px)`. No iOS-specific shell needed for web.

---

### 5. Onboarding / Join Flow (`Onboarding Flow.html`)

**Purpose:** Replaces / extends the current join modal. Full-page multi-step flow accessible at `/join`.

**Steps:**

| Step | Route segment | Content |
|---|---|---|
| Welcome | `/join` | Hero headline + Why Marvel's + studio stats |
| Info | `/join?step=info` | Name, phone, goal (optional), experience (optional) |
| Plan | `/join?step=plan` | 3 plan cards — Group (1,400 EGP), Elite 12 (3,400), Private (2,800) |
| Confirm | `/join?step=confirm` | Summary review + submit |
| Success | `/join?step=success` | Confirmation + WhatsApp CTA |

**The existing `app/join/page.tsx` + `join-form.tsx` should be replaced or extended to support this flow.**

**Plan cards:**
- `border: 1.5px solid rgba(255,255,255,.09)`, `border-radius: 22px`
- Selected state: `border-color: var(--mv-primary)`, radial gradient bg
- Checkmark circle appears on selection (opacity 0 → 1)

**Progress nav:** 5 pip indicators in top-right of nav. Active pip: red gradient + glow. Done pip: solid red.

**Validation:**
- Full name: minimum 2 chars
- Phone: Egyptian format regex `/^(\+20|0)?1[0-9]{9}$/`
- Plan: required before confirm step

**Server action:** `registerClientWithAutoCredentials` already exists in `app/actions/landing.ts`. Wire it to the confirm step submit.

---

### 6. Icon Set (`Icon Set.html`)

56 SVG icons, 24×24px viewBox, `stroke-width="2"`, `stroke-linecap="round"`, `stroke-linejoin="round"`, `fill="none"`.

**All icons are inline SVG strings** — copy directly from `Icon Set.html` (click any icon to copy its SVG). Use as React components:

```tsx
// components/ui/icon.tsx
export function Icon({ name, size = 24, className }: { name: string; size?: number; className?: string }) {
  // Map name to SVG paths
}
```

**Categories and usage mapping:**

| Icon | Use in |
|---|---|
| `dumbbell` | Sessions nav, session type label |
| `calendar` | Book page, schedule page |
| `check` | Attendance confirmed, payment paid |
| `warning` | Overdue payments, missed sessions, capacity full |
| `plus` | Add client CTA, create session CTA |
| `user` | Profile, client detail |
| `users` | Roster, coach clients |
| `coach-badge` | Coach role indicator (shield SVG) |
| `bar-chart` | Progress tab, overview stats |
| `note` / `edit` | Session notes, edit record |
| `message` | WhatsApp / coach message CTA |
| `bell` | Notifications |

---

## Interactions & Behavior

### Animations
```css
/* Page/section reveal */
@keyframes fadeInUp {
  from { opacity: 0; transform: translateY(20px); }
  to   { opacity: 1; transform: translateY(0); }
}
/* Stagger: delay .1s per element */

/* Modal entrance */
@keyframes modalIn {
  from { opacity: 0; transform: scale(.96) translateY(16px); }
  to   { opacity: 1; transform: scale(1) translateY(0); }
}
/* duration: .28s, easing: cubic-bezier(.16,1,.3,1) */

/* Success ring pop */
@keyframes popIn {
  from { opacity: 0; transform: scale(.5); }
  to   { opacity: 1; transform: scale(1); }
}
/* duration: .5s, easing: cubic-bezier(.16,1.5,.3,1) */
```

### Buttons — all interactive states
```css
.btn:hover:not(:disabled) { transform: translateY(-1px); }
.btn:focus-visible { outline: 2px solid var(--mv-primary); outline-offset: 3px; }
.btn:disabled { opacity: .5; cursor: not-allowed; transform: none; }
```

### Sidebar
- Mobile: `transform: translateX(-100%)` → `translateX(0)`, `transition: .24s cubic-bezier(.16,1,.3,1)`
- Desktop (≥1024px): `position: sticky; top: 12px; height: calc(100vh - 24px)`
- Active link: `box-shadow: inset 3px 0 0 var(--mv-primary)`
- Backdrop: `background: rgba(0,0,0,.72); backdrop-filter: blur(10px)`

### FAQ Accordion
```css
.faq-answer { display: grid; grid-template-rows: 0fr; transition: grid-template-rows .28s ease; }
.faq-answer.open { grid-template-rows: 1fr; }
.faq-answer-inner { overflow: hidden; }
```
Only one item open at a time. Toggle `aria-expanded` on button.

### Topbar search
Decorative only (no real search yet). `cursor: default`. Future: slash key focus shortcut.

---

## State Management

### Client mobile
- Tab navigation: local state, persist to `localStorage`
- Booking selection: local state in BookScreen
- Progress data: fetch from `/api/client/progress` (create this endpoint)

### Onboarding flow
- Form state: React `useState`, persist step to URL query param
- Submission: `registerClientWithAutoCredentials` server action
- Success: redirect to `/join?step=success` with auto-generated credentials shown

### Dashboard pages
- All server components where possible
- Client components only for: search/filter state, modal open/close, attendance marking
- Optimistic updates already implemented in existing workspaces — follow the same pattern

---

## Assets

- `public/img/Logo-1.png` — square logo mark (used in BrandLockup, sidebar)
- `public/img/Logo-2.png` — alternate
- `public/img/Logo-3.png` — wide logo (used in landing, footer)
- All logos: `filter: brightness(0) invert(1)` on dark backgrounds

---

## Files in This Bundle

| File | What it is |
|---|---|
| `Design System.html` | Full token + component reference |
| `Landing Page.html` | Landing page prototype |
| `Admin Dashboard.html` | Admin dashboard (7 workspaces) |
| `Coach Dashboard.html` | Coach dashboard (5 workspaces) |
| `Client Mobile.html` | Client mobile app (4 screens) |
| `Onboarding Flow.html` | Join flow (5 steps) |
| `Icon Set.html` | 56 SVG icons (click to copy) |
| `README.md` | This file |

---

## Priority Order for Implementation

1. **Client routes** (`/client/*`) — member-facing, highest business impact, currently missing
2. **Onboarding flow** — replace current basic join modal with full `/join` page
3. **Schedule workspace** (`/admin/schedule`) — missing, needed operationally
4. **Payments workspace** (`/admin/payments`) — missing, needed for billing
5. **Coach Settings** — small, complete the coach portal
6. **Landing page polish** — announce bar, scroll reveal, all sections
7. **Icon system** — wire up SVG icons across all existing components

---

*Generated by Claude Designer · Marvel's Fit Studios · April 2026*
